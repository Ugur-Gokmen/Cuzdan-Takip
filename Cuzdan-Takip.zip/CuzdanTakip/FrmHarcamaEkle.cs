﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;
using static CuzdanTakip.DatabaseHelper;
using CuzdanTakip;

namespace CuzdanTakip
{
    public partial class FrmHarcamaEkle : Form
    {

        private List<Transaction> islemler = new List<Transaction>();
        private DatabaseHelper dbHelper = new DatabaseHelper();
        private List<Transaction> harcamalar = new List<Transaction>();
        public FrmHarcamaEkle()
        {
            this.lblKategori = new System.Windows.Forms.Label();
            this.cmbKategori = new System.Windows.Forms.ComboBox();
            this.lblTutar = new System.Windows.Forms.Label();
            this.txtTutar = new System.Windows.Forms.TextBox();
            this.lblAciklama = new System.Windows.Forms.Label();
            this.txtAciklama = new System.Windows.Forms.TextBox();
            this.lblTarih = new System.Windows.Forms.Label();
            this.dtpTarih = new System.Windows.Forms.DateTimePicker();
            this.btnEkle = new System.Windows.Forms.Button();
            this.lblTip = new System.Windows.Forms.Label();
            this.cmbTip = new System.Windows.Forms.ComboBox();
            InitializeComponent();

        }


        private void FrmHarcamaEkle_Load(object sender, EventArgs e)
        {
            cmbKategori.Items.AddRange(new string[] { "Gıda", "Ulaşım", "Fatura", "Eğlence", "Sağlık" });
            cmbTip.Items.AddRange(new string[] { "Gelir", "Gider" });
            cmbKategori.SelectedIndex = 0;
            cmbTip.SelectedIndex = 1;
            lvHarcamalar.Columns.Add("Kategori", 100);
            lvHarcamalar.Columns.Add("Tutar", 80);
            lvHarcamalar.Columns.Add("Açıklama", 150);
            lvHarcamalar.Columns.Add("Tarih", 100);
            lvHarcamalar.Columns.Add("Tip", 80);

            VerileriGetir();
        }

        private void VerileriGetir()
        {
            lvHarcamalar.Items.Clear();
            DatabaseHelper db = new DatabaseHelper();
            List<Transaction> harcamalar = db.GetAllHarcamalar();

            foreach (var h in harcamalar)
            {
                ListViewItem item = new ListViewItem(h.Category);
                item.SubItems.Add(h.Amount.ToString("C2"));
                item.SubItems.Add(h.Description);
                item.SubItems.Add(h.Date.ToShortDateString());
                item.SubItems.Add(h.Type);

                lvHarcamalar.Items.Add(item);
            }
        }


        private void btnEkle_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtTutar.Text) || cmbKategori.SelectedItem == null || cmbTip.SelectedItem == null)
            {
                MessageBox.Show("Lütfen tüm alanları doldurunuz.");
                return;
            }

            if (!decimal.TryParse(txtTutar.Text, out decimal amount))
            {
                MessageBox.Show("Lütfen geçerli bir tutar giriniz.");
                return;
            }


            Transaction yeniIslem = new Transaction
            {
                Category = cmbKategori.SelectedItem.ToString(),
                Amount = decimal.Parse(txtTutar.Text),
                Description = txtAciklama.Text,
                Date = dtpTarih.Value,
                Type = cmbTip.SelectedItem.ToString()
            };

            islemler.Add(yeniIslem);

            try
            {
                dbHelper.KaydetHarcama(yeniIslem);
                MessageBox.Show("Harcamınız veritabanına kaydedildi.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Veritabanı hatası: " + ex.Message);
            }

            Transaction yeniHarcama = new Transaction
            {
                Category = cmbKategori.SelectedItem.ToString(),
                Amount = decimal.Parse(txtTutar.Text),
                Description = txtAciklama.Text,
                Date = dtpTarih.Value,
                Type = rdbGider.Checked ? "Gider" : "Gelir"
            };

            DatabaseHelper db = new DatabaseHelper();
            db.KaydetHarcama(yeniHarcama);

            MessageBox.Show("Harcama başarıyla kaydedildi.");

            // DataGridView güncelle
            dgvHarcamaListesi.DataSource = null;
            dgvHarcamaListesi.DataSource = islemler;

            // Form alanlarını temizle
            txtTutar.Clear();
            txtAciklama.Clear();
            cmbKategori.SelectedIndex = 0;
            cmbTip.SelectedIndex = 1;
            dtpTarih.Value = DateTime.Now;

        }
    

    private void btnSil_Click(object sender, EventArgs e)
        {
            if (lvHarcamalar.SelectedItems.Count == 0)
            {
                MessageBox.Show("Lütfen silmek istediğiniz harcamayı seçin.");
                return;
            }

            int index = lvHarcamalar.SelectedIndices[0];
            var secilen = harcamalar[index]; // harcamalar listesi formda tanımlı olmalı

            DialogResult result = MessageBox.Show("Silmek istediğinize emin misiniz?", "Onay", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                DatabaseHelper db = new DatabaseHelper();
                db.SilHarcama(secilen.Id);
                MessageBox.Show("Harcama silindi!");
                VerileriGetir();
            }
        }
        private void lvHarcamalar_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lvHarcamalar.SelectedItems.Count > 0)
            {
                int index = lvHarcamalar.SelectedIndices[0];
                Transaction secilen = harcamalar[index]; // harcamalar: Form'da tanımlı liste

                // Formdaki alanlara aktar
                cmbKategori.SelectedItem = secilen.Category;
                txtTutar.Text = secilen.Amount.ToString();
                txtAciklama.Text = secilen.Description;
                dtpTarih.Value = secilen.Date;
                cmbTip.SelectedItem = secilen.Type;
            }
        }
        private void btnGuncelle_Click(object sender, EventArgs e)
        {
            if (lvHarcamalar.SelectedItems.Count == 0)
            {
                MessageBox.Show("Lütfen güncellemek istediğiniz harcamayı seçin.");
                return;
            }

            int index = lvHarcamalar.SelectedIndices[0];
            Transaction secilen = harcamalar[index];

            // Yeni verileri al
            secilen.Category = cmbKategori.SelectedItem.ToString();
            secilen.Amount = decimal.Parse(txtTutar.Text);
            secilen.Description = txtAciklama.Text;
            secilen.Date = dtpTarih.Value;
            secilen.Type = cmbTip.SelectedItem.ToString();

            // Veritabanında güncelle
            DatabaseHelper db = new DatabaseHelper();
            db.GuncelleHarcama(secilen);

            MessageBox.Show("Harcama güncellendi!");
            VerileriGetir(); // Listeyi tazele
        }
    }

}
