﻿using System.Windows.Forms;

namespace CuzdanTakip
{
    partial class FrmHarcamaEkle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        /// 

        private void InitializeComponent()
        {
            this.lblKategori = new System.Windows.Forms.Label();
            this.cmbKategori = new System.Windows.Forms.ComboBox();
            this.lblTutar = new System.Windows.Forms.Label();
            this.txtTutar = new System.Windows.Forms.TextBox();
            this.lblAciklama = new System.Windows.Forms.Label();
            this.txtAciklama = new System.Windows.Forms.TextBox();
            this.lblTarih = new System.Windows.Forms.Label();
            this.dtpTarih = new System.Windows.Forms.DateTimePicker();
            this.btnEkle = new System.Windows.Forms.Button();
            this.lblTip = new System.Windows.Forms.Label();
            this.cmbTip = new System.Windows.Forms.ComboBox();
            this.dgvHarcamaListesi = new System.Windows.Forms.DataGridView();
            this.rdbGider = new System.Windows.Forms.RadioButton();
            this.lvHarcamalar = new System.Windows.Forms.ListView();
            this.btnSil = new System.Windows.Forms.Button();
            this.btnGuncelle = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHarcamaListesi)).BeginInit();
            this.SuspendLayout();
            // 
            // lblKategori
            // 
            this.lblKategori.AutoSize = true;
            this.lblKategori.Location = new System.Drawing.Point(30, 30);
            this.lblKategori.Name = "lblKategori";
            this.lblKategori.Size = new System.Drawing.Size(60, 16);
            this.lblKategori.TabIndex = 11;
            this.lblKategori.Text = "Kategori:";
            // 
            // cmbKategori
            // 
            this.cmbKategori.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbKategori.FormattingEnabled = true;
            this.cmbKategori.Location = new System.Drawing.Point(120, 27);
            this.cmbKategori.Name = "cmbKategori";
            this.cmbKategori.Size = new System.Drawing.Size(200, 24);
            this.cmbKategori.TabIndex = 10;
            // 
            // lblTutar
            // 
            this.lblTutar.AutoSize = true;
            this.lblTutar.Location = new System.Drawing.Point(30, 70);
            this.lblTutar.Name = "lblTutar";
            this.lblTutar.Size = new System.Drawing.Size(41, 16);
            this.lblTutar.TabIndex = 9;
            this.lblTutar.Text = "Tutar:";
            // 
            // txtTutar
            // 
            this.txtTutar.Location = new System.Drawing.Point(120, 67);
            this.txtTutar.Name = "txtTutar";
            this.txtTutar.Size = new System.Drawing.Size(200, 22);
            this.txtTutar.TabIndex = 8;
            // 
            // lblAciklama
            // 
            this.lblAciklama.AutoSize = true;
            this.lblAciklama.Location = new System.Drawing.Point(30, 110);
            this.lblAciklama.Name = "lblAciklama";
            this.lblAciklama.Size = new System.Drawing.Size(66, 16);
            this.lblAciklama.TabIndex = 7;
            this.lblAciklama.Text = "Açıklama:";
            // 
            // txtAciklama
            // 
            this.txtAciklama.Location = new System.Drawing.Point(120, 107);
            this.txtAciklama.Name = "txtAciklama";
            this.txtAciklama.Size = new System.Drawing.Size(200, 22);
            this.txtAciklama.TabIndex = 6;
            // 
            // lblTarih
            // 
            this.lblTarih.AutoSize = true;
            this.lblTarih.Location = new System.Drawing.Point(30, 150);
            this.lblTarih.Name = "lblTarih";
            this.lblTarih.Size = new System.Drawing.Size(41, 16);
            this.lblTarih.TabIndex = 5;
            this.lblTarih.Text = "Tarih:";
            // 
            // dtpTarih
            // 
            this.dtpTarih.Location = new System.Drawing.Point(120, 147);
            this.dtpTarih.Name = "dtpTarih";
            this.dtpTarih.Size = new System.Drawing.Size(200, 22);
            this.dtpTarih.TabIndex = 4;
            // 
            // btnEkle
            // 
            this.btnEkle.Location = new System.Drawing.Point(120, 230);
            this.btnEkle.Name = "btnEkle";
            this.btnEkle.Size = new System.Drawing.Size(200, 30);
            this.btnEkle.TabIndex = 1;
            this.btnEkle.Text = "Harcama Ekle";
            this.btnEkle.UseVisualStyleBackColor = true;
            this.btnEkle.Click += new System.EventHandler(this.btnEkle_Click);
            // 
            // lblTip
            // 
            this.lblTip.AutoSize = true;
            this.lblTip.Location = new System.Drawing.Point(30, 190);
            this.lblTip.Name = "lblTip";
            this.lblTip.Size = new System.Drawing.Size(30, 16);
            this.lblTip.TabIndex = 3;
            this.lblTip.Text = "Tip:";
            // 
            // cmbTip
            // 
            this.cmbTip.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTip.FormattingEnabled = true;
            this.cmbTip.Location = new System.Drawing.Point(120, 187);
            this.cmbTip.Name = "cmbTip";
            this.cmbTip.Size = new System.Drawing.Size(200, 24);
            this.cmbTip.TabIndex = 2;
            // 
            // dgvHarcamaListesi
            // 
            this.dgvHarcamaListesi.AllowUserToAddRows = false;
            this.dgvHarcamaListesi.ColumnHeadersHeight = 29;
            this.dgvHarcamaListesi.Location = new System.Drawing.Point(352, 30);
            this.dgvHarcamaListesi.Name = "dgvHarcamaListesi";
            this.dgvHarcamaListesi.ReadOnly = true;
            this.dgvHarcamaListesi.RowHeadersWidth = 51;
            this.dgvHarcamaListesi.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvHarcamaListesi.Size = new System.Drawing.Size(598, 230);
            this.dgvHarcamaListesi.TabIndex = 0;
            // 
            // rdbGider
            // 
            this.rdbGider.AutoSize = true;
            this.rdbGider.Location = new System.Drawing.Point(29, 235);
            this.rdbGider.Name = "rdbGider";
            this.rdbGider.Size = new System.Drawing.Size(61, 20);
            this.rdbGider.TabIndex = 12;
            this.rdbGider.TabStop = true;
            this.rdbGider.Text = "Gider";
            this.rdbGider.UseVisualStyleBackColor = true;
            // 
            // lvHarcamalar
            // 
            this.lvHarcamalar.FullRowSelect = true;
            this.lvHarcamalar.GridLines = true;
            this.lvHarcamalar.HideSelection = false;
            this.lvHarcamalar.Location = new System.Drawing.Point(12, 341);
            this.lvHarcamalar.Name = "lvHarcamalar";
            this.lvHarcamalar.Size = new System.Drawing.Size(948, 119);
            this.lvHarcamalar.TabIndex = 0;
            this.lvHarcamalar.UseCompatibleStateImageBehavior = false;
            this.lvHarcamalar.View = System.Windows.Forms.View.Details;
            // 
            // btnSil
            // 
            this.btnSil.Location = new System.Drawing.Point(120, 267);
            this.btnSil.Name = "btnSil";
            this.btnSil.Size = new System.Drawing.Size(200, 23);
            this.btnSil.TabIndex = 13;
            this.btnSil.Text = "Seçili Harcamayı Sil";
            this.btnSil.UseVisualStyleBackColor = true;
            // 
            // btnGuncelle
            // 
            this.btnGuncelle.Location = new System.Drawing.Point(120, 297);
            this.btnGuncelle.Name = "btnGuncelle";
            this.btnGuncelle.Size = new System.Drawing.Size(200, 23);
            this.btnGuncelle.TabIndex = 14;
            this.btnGuncelle.Text = "Seçiliyi Güncelle";
            this.btnGuncelle.UseVisualStyleBackColor = true;
            // 
            // FrmHarcamaEkle
            // 
            this.ClientSize = new System.Drawing.Size(980, 458);
            this.Controls.Add(this.btnGuncelle);
            this.Controls.Add(this.btnSil);
            this.Controls.Add(this.rdbGider);
            this.Controls.Add(this.dgvHarcamaListesi);
            this.Controls.Add(this.btnEkle);
            this.Controls.Add(this.cmbTip);
            this.Controls.Add(this.lblTip);
            this.Controls.Add(this.dtpTarih);
            this.Controls.Add(this.lblTarih);
            this.Controls.Add(this.txtAciklama);
            this.Controls.Add(this.lblAciklama);
            this.Controls.Add(this.txtTutar);
            this.Controls.Add(this.lblTutar);
            this.Controls.Add(this.cmbKategori);
            this.Controls.Add(this.lblKategori);
            this.Controls.Add(this.lvHarcamalar);
            this.Name = "FrmHarcamaEkle";
            this.Text = "Harcama Ekle";
            this.Load += new System.EventHandler(this.FrmHarcamaEkle_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvHarcamaListesi)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion
        private System.Windows.Forms.Label lblKategori;
        private System.Windows.Forms.ComboBox cmbKategori;
        private System.Windows.Forms.Label lblTutar;
        private System.Windows.Forms.TextBox txtTutar;
        private System.Windows.Forms.Label lblAciklama;
        private System.Windows.Forms.TextBox txtAciklama;
        private System.Windows.Forms.Label lblTarih;
        private System.Windows.Forms.DateTimePicker dtpTarih;
        private System.Windows.Forms.Button btnEkle;
        private System.Windows.Forms.Label lblTip;
        private System.Windows.Forms.ComboBox cmbTip;
        private System.Windows.Forms.DataGridView dgvHarcamaListesi;
        private System.Windows.Forms.RadioButton rdbGider;
        private System.Windows.Forms.ListView lvHarcamalar;
        private Button btnSil;
        private Button btnGuncelle;
    }

}




