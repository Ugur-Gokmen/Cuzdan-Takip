﻿using CuzdanTakip;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace CuzdanTakip
{
    public class DatabaseHelper
    {
        private string connectionString = "Server=localhost;Database=CuzdanTakipDB;Trusted_Connection=True;";

        public void KaydetHarcama(Transaction t)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Harcamalar (Kategori, Tutar, Aciklama, Tarih, Tip) " +
                               "VALUES (@kategori, @tutar, @aciklama, @tarih, @tip)";

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@kategori", t.Category);
                    cmd.Parameters.AddWithValue("@tutar", t.Amount);
                    cmd.Parameters.AddWithValue("@aciklama", t.Description);
                    cmd.Parameters.AddWithValue("@tarih", t.Date);
                    cmd.Parameters.AddWithValue("@tip", t.Type);

                    try
                    {
                        con.Open();
                        cmd.ExecuteNonQuery();
                    }
                    catch (Exception ex)
                    {
                        // Hata kontrolü
                        System.Windows.Forms.MessageBox.Show("Hata oluştu: " + ex.Message);
                    }
                }
            }
        }

        // İstersen ilerleyen aşamada buraya Harcama Sil, Güncelle, Listele gibi metotlar ekleyebiliriz.

        public List<Transaction> GetAllHarcamalar()
        {
            List<Transaction> list = new List<Transaction>();

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "SELECT Id,Kategori, Tutar, Aciklama, Tarih, Tip FROM Harcamalar";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    con.Open();
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            Transaction t = new Transaction
                            {
                                Id = Convert.ToInt32(reader["Id"]),
                                Category = reader["Kategori"].ToString(),
                                Amount = Convert.ToDecimal(reader["Tutar"]),
                                Description = reader["Aciklama"].ToString(),
                                Date = Convert.ToDateTime(reader["Tarih"]),
                                Type = reader["Tip"].ToString()
                            };
                            list.Add(t);
                        }
                    }
                }
            }

            return list;
        }

        public void SilHarcama(int id)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = "DELETE FROM Harcamalar WHERE Id = @id";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@id", id);
                    con.Open();
                    cmd.ExecuteNonQuery();
                }
            }
        }
        public void GuncelleHarcama(Transaction t)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = @"UPDATE Harcamalar SET 
                            Kategori = @kategori,
                            Tutar = @tutar,
                            Aciklama = @aciklama,
                            Tarih = @tarih,
                            Tip = @tip
                         WHERE Id = @id";

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@kategori", t.Category);
                    cmd.Parameters.AddWithValue("@tutar", t.Amount);
                    cmd.Parameters.AddWithValue("@aciklama", t.Description);
                    cmd.Parameters.AddWithValue("@tarih", t.Date);
                    cmd.Parameters.AddWithValue("@tip", t.Type);
                    cmd.Parameters.AddWithValue("@id", t.Id);

                    con.Open();
                    cmd.ExecuteNonQuery();
                }
            }
        }

    }
}